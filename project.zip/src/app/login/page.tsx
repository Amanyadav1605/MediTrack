"use client"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center">
        <h1 className="text-2xl font-bold">Redirecting to Dashboard...</h1>
        <p className="text-muted-foreground mt-2">Authentication is currently disabled.</p>
      </div>
    </div>
  )
}
