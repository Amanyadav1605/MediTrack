
'use client'

import { useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { AlertCircle, RefreshCcw } from 'lucide-react'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#F8F9FB] text-center">
      <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mb-6">
        <AlertCircle className="w-8 h-8 text-destructive" />
      </div>
      <h2 className="text-3xl font-bold font-headline mb-2">Something went wrong!</h2>
      <p className="text-muted-foreground max-w-md mb-8">
        We encountered an unexpected error. Our team has been notified.
      </p>
      <div className="flex gap-4">
        <Button 
          onClick={() => reset()}
          className="rounded-xl font-bold px-6 shadow-lg shadow-primary/20"
        >
          <RefreshCcw className="mr-2 h-4 w-4" /> Try again
        </Button>
        <Button 
          variant="outline" 
          onClick={() => window.location.href = '/'}
          className="rounded-xl font-bold px-6"
        >
          Back to Home
        </Button>
      </div>
    </div>
  )
}
