'use client';

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Activity, Shield, Brain, ArrowRight, Sparkles, CheckCircle, Zap } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FB]">
      <nav className="h-20 border-b flex items-center justify-between px-6 md:px-20 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Activity className="text-white w-5 h-5" />
          </div>
          <span className="font-headline font-bold text-2xl tracking-tight text-primary">MediTrack</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <Link href="#features" className="text-sm font-semibold hover:text-primary transition-colors">Platform</Link>
          <Link href="#ai" className="text-sm font-semibold hover:text-primary transition-colors">Intelligence</Link>
          <Link href="#security" className="text-sm font-semibold hover:text-primary transition-colors">Privacy</Link>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/patient">
            <Button className="rounded-full px-8 shadow-xl shadow-primary/20 font-bold bg-primary hover:bg-primary/90">
              Open Dashboard
            </Button>
          </Link>
        </div>
      </nav>

      <main className="flex-1">
        <section className="relative py-24 px-6 md:px-20 text-center space-y-12 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-30">
             <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px]"></div>
             <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-200/20 rounded-full blur-[120px]"></div>
          </div>

          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary/10 rounded-full border border-primary/20 mb-4 animate-in fade-in zoom-in duration-700">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs font-black text-primary uppercase tracking-[0.2em]">Patient Intelligence Platform</span>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-headline font-black tracking-tighter max-w-5xl mx-auto leading-[0.95]">
            Your Health Data, <br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-cyan-500">Intelligently Managed.</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed font-medium">
            The next generation of clinical self-care. Securely track vitals, analyze complex symptoms with AI, and summarize medical reports in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-8">
            <Link href="/patient">
              <Button className="h-16 px-12 rounded-full text-lg font-black shadow-2xl shadow-primary/30 transition-all hover:scale-105 active:scale-95">
                Launch Health Portal <ArrowRight className="ml-3 w-6 h-6" />
              </Button>
            </Link>
            <div className="flex -space-x-3 overflow-hidden">
               {[1,2,3,4].map(i => (
                 <div key={i} className="inline-block h-12 w-12 rounded-full ring-4 ring-white">
                    <img src={`https://picsum.photos/seed/user${i}/100/100`} alt="user" className="rounded-full" />
                 </div>
               ))}
               <div className="flex items-center justify-center h-12 w-12 rounded-full bg-slate-100 ring-4 ring-white text-[10px] font-bold text-slate-600">
                  +2k
               </div>
            </div>
          </div>
        </section>

        <section id="features" className="py-32 bg-white px-6 md:px-20 relative">
          <div className="text-center space-y-6 mb-24">
            <h2 className="text-4xl md:text-5xl font-headline font-black tracking-tight">The Clinical Advantage</h2>
            <p className="text-muted-foreground max-w-xl mx-auto text-lg font-medium leading-relaxed">Built with advanced Genkit AI tools and production-grade security for the modern patient.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-7xl mx-auto">
            <FeatureCard 
              icon={Brain} 
              title="Clinical Reasoning" 
              description="Our AI symptom checker uses advanced diagnostic logic to assess potential conditions with high confidence scoring." 
              accent="bg-primary"
            />
            <FeatureCard 
              icon={Shield} 
              title="Encrypted Vault" 
              description="Military-grade security ensures your clinical records, lab results, and personal health data remain exclusively yours." 
              accent="bg-emerald-500"
            />
            <FeatureCard 
              icon={Zap} 
              title="Real-time Sync" 
              description="Automatically synchronize your vitals and medications with our intelligent monitoring engine for proactive care." 
              accent="bg-amber-500"
            />
          </div>
        </section>

        <section className="py-24 bg-slate-900 text-white px-6 md:px-20 overflow-hidden relative">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div className="space-y-8">
                 <h2 className="text-4xl md:text-6xl font-headline font-black leading-tight">AI Assistance <br />That Actually Knows You.</h2>
                 <p className="text-slate-400 text-lg leading-relaxed">Unlike generic LLMs, MediTrack AI Assistant securely references your clinical history, medication logs, and vital trends to provide contextually accurate health support.</p>
                 <div className="space-y-4">
                    {[
                      "Real-time vital trend analysis",
                      "Medication interaction checks",
                      "Simplified report summaries",
                      "Appointment preparation"
                    ].map(text => (
                      <div key={text} className="flex items-center gap-3">
                         <div className="p-1 rounded-full bg-primary/20 text-primary">
                            <CheckCircle className="w-5 h-5" />
                         </div>
                         <span className="font-bold text-slate-200">{text}</span>
                      </div>
                    ))}
                 </div>
              </div>
              <div className="relative group">
                 <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full group-hover:scale-110 transition-transform"></div>
                 <Card className="bg-slate-800 border-slate-700 p-8 rounded-[3rem] shadow-2xl relative overflow-hidden">
                    <div className="flex items-center gap-4 mb-8">
                       <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center">
                          <Activity className="text-white w-6 h-6" />
                       </div>
                       <div>
                          <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">MediTrack Engine</p>
                          <p className="text-xl font-bold">Health Status: Optimal</p>
                       </div>
                    </div>
                    <div className="space-y-6">
                       <div className="h-4 bg-slate-700 rounded-full w-full"></div>
                       <div className="h-4 bg-slate-700 rounded-full w-3/4"></div>
                       <div className="h-4 bg-slate-700 rounded-full w-5/6"></div>
                    </div>
                 </Card>
              </div>
           </div>
        </section>
      </main>

      <footer className="bg-[#0A0D12] text-white py-24 px-6 md:px-20 border-t border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
          <div className="space-y-8">
            <div className="flex items-center gap-3">
              <Activity className="text-primary w-8 h-8" />
              <span className="font-headline font-bold text-3xl tracking-tight">MediTrack</span>
            </div>
            <p className="text-slate-400 text-base leading-relaxed font-medium">Engineering the future of patient self-care through privacy, precision, and medical intelligence.</p>
          </div>
          <div>
            <h4 className="font-black text-lg mb-8 uppercase tracking-widest text-primary">Capabilities</h4>
            <ul className="space-y-4 text-slate-400 font-bold">
              <li className="hover:text-primary transition-colors cursor-pointer">Symptom Diagnostic</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Clinical Chat</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Medication Sync</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Vault Security</li>
            </ul>
          </div>
          <div>
            <h4 className="font-black text-lg mb-8 uppercase tracking-widest text-primary">Ecosystem</h4>
            <ul className="space-y-4 text-slate-400 font-bold">
              <li className="hover:text-primary transition-colors cursor-pointer">For Patients</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Clinical API</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Privacy Charter</li>
              <li className="hover:text-primary transition-colors cursor-pointer">Developer Hub</li>
            </ul>
          </div>
          <div>
            <h4 className="font-black text-lg mb-8 uppercase tracking-widest text-primary">Updates</h4>
            <p className="text-slate-400 mb-6 font-medium">Join 2,000+ early adopters for clinical insights.</p>
            <div className="flex flex-col gap-3">
              <Input className="bg-white/5 border-white/10 text-white rounded-2xl h-14 px-6 focus:ring-primary/50" placeholder="medical@email.com" />
              <Button className="rounded-2xl bg-primary hover:bg-primary/90 h-14 font-black text-lg">Subscribe</Button>
            </div>
          </div>
        </div>
        <div className="mt-24 pt-10 border-t border-white/5 text-center text-slate-500 text-sm font-black uppercase tracking-[0.3em]">
          © 2025 MediTrack Systems. All rights reserved.
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon: Icon, title, description, accent }: { icon: any, title: string, description: string, accent: string }) {
  return (
    <div className="p-12 rounded-[3.5rem] bg-slate-50 border border-transparent hover:border-primary/10 hover:bg-white transition-all group shadow-sm hover:shadow-2xl">
      <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center mb-10 shadow-lg group-hover:scale-110 transition-transform ${accent}`}>
        <Icon className="w-10 h-10 text-white" />
      </div>
      <h3 className="text-3xl font-black mb-6 font-headline tracking-tight">{title}</h3>
      <p className="text-muted-foreground leading-relaxed text-lg font-medium">{description}</p>
    </div>
  )
}
