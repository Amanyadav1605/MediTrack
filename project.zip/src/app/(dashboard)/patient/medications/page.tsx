"use client"

import { useState, useMemo, useEffect } from "react"
import { Pill, Plus, Clock, CheckCircle, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useCollection, useUser, useFirestore } from "@/firebase"
import { collection, updateDoc, doc, serverTimestamp, addDoc } from "firebase/firestore"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"

export default function MedicationsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const [isAddOpen, setIsAddOpen] = useState(false)
  const [newMed, setNewMed] = useState({ name: "", dose: "", timing: "", frequency: "Daily", status: "Upcoming" })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const userId = user?.uid || "guest-user"

  const medicationsQuery = useMemo(() => {
    if (!db) return null
    return collection(db, "users", userId, "medications")
  }, [db, userId])

  const { data: medications, loading } = useCollection(medicationsQuery)

  const handleMarkTaken = async (medId: string) => {
    if (!db) return
    const medRef = doc(db, "users", userId, "medications", medId)
    try {
      updateDoc(medRef, {
        status: "Taken",
        lastTaken: serverTimestamp()
      })
      toast({ title: "Done", description: "Medication marked as taken in database." })
    } catch (error) {
      toast({ variant: "destructive", title: "Database Error", description: "Action failed." })
    }
  }

  const handleAddMedication = async () => {
    if (!db || !newMed.name) {
      toast({ variant: "destructive", title: "Error", description: "Please enter a medication name." })
      return
    }
    try {
      addDoc(collection(db, "users", userId, "medications"), {
        ...newMed,
        status: "Due",
        createdAt: serverTimestamp()
      })
      toast({ title: "Success", description: "Medication added to your medical database." })
      setIsAddOpen(false)
      setNewMed({ name: "", dose: "", timing: "", frequency: "Daily", status: "Upcoming" })
    } catch (error) {
      toast({ variant: "destructive", title: "Database Error", description: "Failed to save medication." })
    }
  }

  const adherence = medications?.length 
    ? Math.round((medications.filter(m => m.status === "Taken").length / medications.length) * 100)
    : 0

  const missedDoses = medications?.filter(m => m.status === "Due").length || 0

  if (!mounted) return null

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline">Medication Database</h1>
          <p className="text-muted-foreground mt-1">Manage prescriptions and tracking in your secure health vault.</p>
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl h-11 px-6 shadow-lg shadow-primary/20 font-bold">
              <Plus className="mr-2 h-4 w-4" /> Add New Prescription
            </Button>
          </DialogTrigger>
          <DialogContent className="rounded-3xl">
            <DialogHeader>
              <DialogTitle className="font-headline text-2xl">Add Medication</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Medication Name</Label>
                <Input value={newMed.name} onChange={(e) => setNewMed({...newMed, name: e.target.value})} placeholder="e.g. Lisinopril" className="rounded-xl" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Dose</Label>
                  <Input value={newMed.dose} onChange={(e) => setNewMed({...newMed, dose: e.target.value})} placeholder="e.g. 10mg" className="rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>Timing</Label>
                  <Input value={newMed.timing} onChange={(e) => setNewMed({...newMed, timing: e.target.value})} placeholder="e.g. 8:00 AM" className="rounded-xl" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select value={newMed.frequency} onValueChange={(val) => setNewMed({...newMed, frequency: val})}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    <SelectItem value="Daily">Daily</SelectItem>
                    <SelectItem value="Twice Daily">Twice Daily</SelectItem>
                    <SelectItem value="Weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleAddMedication} className="rounded-xl w-full font-bold">Save to Database</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-sm rounded-2xl overflow-hidden bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-headline flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-500" />
              Database Adherence
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline justify-between mb-2">
              <p className="text-4xl font-black text-foreground">{adherence}%</p>
              <Badge className={adherence > 80 ? "bg-emerald-100 text-emerald-700 border-none" : "bg-amber-100 text-amber-700 border-none"}>
                {adherence > 80 ? "Excellent" : "Needs Attention"}
              </Badge>
            </div>
            <Progress value={adherence} className="h-2 bg-emerald-100" />
            <p className="text-xs text-muted-foreground mt-4 italic">Tracking logs from your medication database.</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm rounded-2xl overflow-hidden bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-headline flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-500" />
              Pending Doses
            </CardTitle>
          </CardHeader>
          <CardContent>
             <p className="text-4xl font-black text-rose-600">{missedDoses}</p>
             <p className="text-sm text-muted-foreground mt-1">Recorded as due today</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm rounded-2xl overflow-hidden bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-headline flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Next Reminder
            </CardTitle>
          </CardHeader>
          <CardContent>
             <p className="text-2xl font-bold">MediSync Enabled</p>
             <p className="text-sm text-primary font-medium mt-1">Automatic database reminders.</p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-bold font-headline px-1">Active Medication Schedule</h3>
        <div className="grid grid-cols-1 gap-4">
          {loading ? (
            <div className="p-12 text-center text-muted-foreground">Accessing database...</div>
          ) : medications?.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-2xl border-2 border-dashed border-muted flex flex-col items-center gap-4">
              <Pill className="w-12 h-12 text-muted/30" />
              <div>
                <p className="font-bold text-lg text-foreground">Database is empty</p>
                <p className="text-muted-foreground text-sm">Start uploading your prescriptions for secure tracking.</p>
              </div>
              <Button variant="outline" className="rounded-xl" onClick={() => setIsAddOpen(true)}>Add First Medication</Button>
            </div>
          ) : (
            medications?.map((med) => (
              <Card key={med.id} className="border-none shadow-sm rounded-2xl hover:shadow-md transition-shadow">
                <CardContent className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="flex items-center gap-5">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                      med.status === "Taken" ? "bg-emerald-50" : med.status === "Due" ? "bg-amber-50" : "bg-primary/5"
                    }`}>
                        <Pill className={`w-7 h-7 ${
                          med.status === "Taken" ? "text-emerald-500" : med.status === "Due" ? "text-amber-500" : "text-primary"
                        }`} />
                    </div>
                    <div className="space-y-1">
                        <h4 className="text-xl font-bold">{med.name}</h4>
                        <p className="text-sm text-muted-foreground">{med.dose} • {med.frequency}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-8">
                    <div className="flex flex-col items-center">
                        <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">Scheduled</p>
                        <p className="font-bold">{med.timing}</p>
                    </div>
                    <div className="flex flex-col items-center min-w-[80px]">
                        <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Status</p>
                        <Badge className={
                          med.status === "Taken" ? "bg-emerald-100 text-emerald-700 border-none" : 
                          med.status === "Due" ? "bg-amber-100 text-amber-700 border-none" : "bg-slate-100 text-slate-700 border-none"
                        }>
                          {med.status}
                        </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                        {med.status === "Due" ? (
                          <Button 
                            className="rounded-xl font-bold bg-primary px-8"
                            onClick={() => handleMarkTaken(med.id)}
                          >
                            Mark as Taken
                          </Button>
                        ) : med.status === "Taken" ? (
                          <Button variant="outline" className="rounded-xl border-emerald-200 text-emerald-600 font-bold" disabled>Logged</Button>
                        ) : (
                          <Button variant="outline" className="rounded-xl font-bold">Edit</Button>
                        )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
