"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { aiSymptomAnalysis, type AiSymptomAnalysisOutput } from "@/ai/flows/ai-symptom-analysis-flow"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Stethoscope, Loader2, AlertTriangle, CheckCircle2, Activity, History } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useFirestore, useUser } from "@/firebase"
import { collection, addDoc, serverTimestamp } from "firebase/firestore"
import { toast } from "@/hooks/use-toast"

const formSchema = z.object({
  age: z.string().transform(v => parseInt(v, 10)).pipe(z.number().min(0).max(120)),
  gender: z.enum(["Male", "Female", "Other", "Prefer not to say"]),
  symptoms: z.string().min(10, "Please describe your symptoms in more detail."),
  existingDiseases: z.string().optional(),
})

export default function SymptomCheckerPage() {
  const { user } = useUser()
  const db = useFirestore()
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<AiSymptomAnalysisOutput | null>(null)

  const userId = user?.uid || "guest-user"

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: 30 as any,
      gender: "Male",
      symptoms: "",
      existingDiseases: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setLoading(true)
    try {
      const diseases = values.existingDiseases ? values.existingDiseases.split(",").map(s => s.trim()) : []
      const analysis = await aiSymptomAnalysis({
        age: values.age,
        gender: values.gender,
        symptoms: values.symptoms,
        existingDiseases: diseases,
      })
      
      setResult(analysis)

      // Store in database history
      if (db) {
        await addDoc(collection(db, "users", userId, "symptom_history"), {
          ...values,
          analysis,
          timestamp: serverTimestamp()
        })
      }
    } catch (error) {
      console.error(error)
      toast({ variant: "destructive", title: "Analysis Error", description: "Failed to connect to AI engine." })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold font-headline">AI Symptom Analysis</h1>
        <p className="text-muted-foreground mt-1">Get an immediate assessment stored securely in your health history.</p>
      </header>

      {!result ? (
        <Card className="border-none shadow-xl rounded-2xl">
          <CardHeader>
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <Stethoscope className="w-6 h-6 text-primary" />
            </div>
            <CardTitle className="font-headline">Symptom Input</CardTitle>
            <CardDescription>Provide details for a clinical-grade AI assessment.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} className="rounded-xl" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Gender</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="rounded-xl">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="rounded-xl">
                            <SelectItem value="Male">Male</SelectItem>
                            <SelectItem value="Female">Female</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="symptoms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>What symptoms are you experiencing?</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="e.g., Recurring chest pain, persistent cough..." 
                          className="min-h-[120px] rounded-xl"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  disabled={loading}
                  className="w-full h-12 rounded-xl text-lg font-bold"
                >
                  {loading ? (
                    <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Analyzing...</>
                  ) : (
                    "Start AI Diagnostic"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6 animate-in fade-in duration-500">
          <div className="flex justify-between items-center">
            <Button variant="outline" onClick={() => setResult(null)} className="rounded-xl">
              New Analysis
            </Button>
            <Badge className="bg-primary/10 text-primary border-none flex items-center gap-1.5 py-1.5 px-3">
              <History className="w-4 h-4" /> Result Saved to History
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 border-none shadow-xl rounded-2xl overflow-hidden">
              <CardHeader className="bg-primary text-primary-foreground">
                <CardTitle className="font-headline flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Potential Conditions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {result.possibleConditions.map((condition, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-muted/30 border border-muted-foreground/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xl font-bold text-foreground">{condition.name}</h4>
                      <Badge variant="secondary" className="rounded-full">
                        {condition.confidencePercentage}% Confidence
                      </Badge>
                    </div>
                    <p className="text-muted-foreground text-sm">{condition.description}</p>
                    <Progress value={condition.confidencePercentage} className="h-1.5" />
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className="border-none shadow-xl rounded-2xl bg-rose-50 border border-rose-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-rose-900 font-headline text-lg flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-rose-500" />
                    Severity: {result.severityScore}/10
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={result.severityScore * 10} className="h-2 bg-rose-200" />
                  <p className="mt-4 text-xs text-rose-800 font-medium">
                    {result.severityScore > 6 ? "High priority assessment required." : "Routine monitoring suggested."}
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-xl rounded-2xl">
                <CardHeader className="pb-2">
                  <CardTitle className="font-headline text-lg">Next Steps</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {result.suggestedActions.map((action, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                      {action}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
