"use client"

import { useState, useRef, useEffect } from "react"
import { aiHealthAssistantChat } from "@/ai/flows/ai-health-assistant-chat-flow"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, Sparkles, Loader2, Info, User, Zap, Calendar, Heart, Pill } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useUser } from "@/firebase"

type Message = {
  role: "user" | "model"
  content: string
  timestamp: string
}

export default function HealthChatPage() {
  const { user } = useUser()
  const [mounted, setMounted] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setMounted(true)
    setMessages([
      { 
        role: "model", 
        content: "Hello! I'm your MediTrack AI Assistant. I have secure access to your vitals, medications, and clinical records. How can I help you manage your health today?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ])
  }, [])

  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [messages, loading])

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input
    if (!textToSend.trim() || loading) return

    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    const userMsg: Message = { role: "user", content: textToSend, timestamp: now }
    
    setMessages(prev => [...prev, userMsg])
    if (!customText) setInput("")
    setLoading(true)

    try {
      const chatHistory = messages.slice(-10).map(({ role, content }) => ({ role, content }))
      const res = await aiHealthAssistantChat({
        userId: user?.uid || "guest-user",
        message: textToSend,
        chatHistory
      })
      
      const modelTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      setMessages(prev => [...prev, { role: "model", content: res.response, timestamp: modelTimestamp }])
    } catch (error) {
      console.error("Chat Error:", error)
      const errorTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      setMessages(prev => [...prev, { role: "model", content: "I encountered an error accessing your health records. Please ensure your data is logged correctly and try again.", timestamp: errorTimestamp }])
    } finally {
      setLoading(false)
    }
  }

  const suggestions = [
    { text: "What are my latest vitals?", icon: Heart },
    { text: "When is my next appointment?", icon: Calendar },
    { text: "My medication schedule", icon: Pill },
    { text: "Tips for better sleep", icon: Sparkles }
  ]

  if (!mounted) return null

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-12rem)] flex flex-col space-y-6 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
              <Bot className="text-white w-6 h-6" />
            </div>
            MediTrack AI Assistant
          </h1>
          <p className="text-muted-foreground mt-1 text-sm md:text-base">Intelligent healthcare support with real-time record synchronization.</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-700 rounded-xl border border-amber-100 shadow-sm max-w-sm">
          <Info className="w-4 h-4 shrink-0" />
          <span className="text-[10px] md:text-xs font-semibold">MediTrack AI provides insights based on your records, not formal medical diagnoses.</span>
        </div>
      </header>

      <Card className="flex-1 border-none shadow-2xl rounded-3xl flex flex-col overflow-hidden bg-white/50 backdrop-blur-sm border border-white/20">
        <CardContent className="flex-1 p-0 flex flex-col h-full overflow-hidden">
          <ScrollArea className="flex-1 p-4 md:p-8" ref={scrollRef}>
            <div className="space-y-8 pb-4">
              {messages.map((m, i) => (
                <div key={i} className={`flex gap-4 ${m.role === "user" ? "flex-row-reverse" : "animate-in slide-in-from-left-2 duration-300"}`}>
                  <Avatar className={`h-10 w-10 border-2 shadow-sm ${m.role === "model" ? "bg-primary border-primary/20" : "bg-white border-muted"}`}>
                    {m.role === "model" ? (
                      <AvatarFallback className="bg-primary text-white"><Bot className="w-5 h-5" /></AvatarFallback>
                    ) : (
                      <AvatarFallback className="bg-slate-100 text-slate-600"><User className="w-5 h-5" /></AvatarFallback>
                    )}
                  </Avatar>
                  <div className={`flex flex-col max-w-[85%] md:max-w-[70%] ${m.role === "user" ? "items-end" : "items-start"}`}>
                    <div className={`px-5 py-3 rounded-2xl text-sm md:text-base leading-relaxed whitespace-pre-wrap shadow-sm ${
                      m.role === "user" 
                        ? "bg-primary text-primary-foreground font-medium rounded-tr-none shadow-primary/20" 
                        : "bg-white text-foreground border border-slate-100 rounded-tl-none"
                    }`}>
                      {m.content}
                    </div>
                    <span className="text-[10px] font-bold text-muted-foreground mt-2 px-1 uppercase tracking-tighter">
                      {m.role === "user" ? "You" : "MediTrack AI"} • {m.timestamp}
                    </span>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <Avatar className="h-10 w-10 border-2 bg-primary border-primary/20 shadow-sm">
                    <AvatarFallback className="bg-primary text-white"><Bot className="w-5 h-5" /></AvatarFallback>
                  </Avatar>
                  <div className="px-6 py-4 rounded-2xl bg-white border border-slate-100 rounded-tl-none flex flex-col gap-3 shadow-sm min-w-[200px]">
                    <div className="flex items-center gap-3">
                      <Loader2 className="w-4 h-4 animate-spin text-primary" />
                      <span className="text-sm font-bold text-slate-600">Assistant is analyzing your records...</span>
                    </div>
                    <div className="flex gap-1">
                      <div className="h-1.5 w-1.5 bg-primary/30 rounded-full animate-bounce delay-75"></div>
                      <div className="h-1.5 w-1.5 bg-primary/30 rounded-full animate-bounce delay-150"></div>
                      <div className="h-1.5 w-1.5 bg-primary/30 rounded-full animate-bounce delay-300"></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-4 md:p-8 bg-slate-50/50 border-t border-slate-100">
            {!loading && (
              <div className="flex flex-wrap gap-2 mb-6 animate-in fade-in slide-in-from-top-2 duration-500">
                {suggestions.map((tip) => (
                  <button 
                    key={tip.text}
                    onClick={() => handleSend(tip.text)}
                    className="flex items-center gap-2 text-xs font-bold px-4 py-2 rounded-xl bg-white border border-slate-200 hover:border-primary hover:text-primary transition-all shadow-sm group"
                  >
                    <tip.icon className="w-3 h-3 text-primary group-hover:scale-125 transition-transform" />
                    {tip.text}
                  </button>
                ))}
              </div>
            )}
            <div className="relative group">
              <Input
                placeholder="Ask about your vitals, meds, or appointments..."
                className="pr-16 h-16 rounded-2xl border-2 border-slate-100 bg-white shadow-xl text-base focus-visible:ring-primary/20 transition-all placeholder:text-slate-400"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />
              <Button 
                className="absolute right-3 top-3 h-10 w-10 rounded-xl p-0 shadow-lg shadow-primary/30 hover:scale-105 active:scale-95 transition-all"
                onClick={() => handleSend()}
                disabled={loading || !input.trim()}
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
