"use client"

import { useState, useMemo, useEffect } from "react"
import { Calendar as CalendarIcon, Clock, MapPin, Video, Plus, Search, ChevronRight, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useCollection, useUser, useFirestore } from "@/firebase"
import { collection, addDoc, query, orderBy } from "firebase/firestore"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"

export default function AppointmentsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const [isBookOpen, setIsBookOpen] = useState(false)
  const [newAppt, setNewAppt] = useState({ doctor: "", specialty: "", date: "", type: "In-Person", location: "" })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const userId = user?.uid || "guest-user"

  const appointmentsQuery = useMemo(() => {
    if (!db) return null
    return query(collection(db, "users", userId, "appointments"), orderBy("date", "asc"))
  }, [db, userId])

  const { data: appointments, loading } = useCollection(appointmentsQuery)

  const handleBookAppointment = async () => {
    if (!db || !newAppt.doctor || !newAppt.date) return
    try {
      addDoc(collection(db, "users", userId, "appointments"), {
        ...newAppt,
        status: "Confirmed",
        image: `https://picsum.photos/seed/${Math.random()}/100/100`
      })
      toast({ title: "Success", description: "Appointment booked successfully." })
      setIsBookOpen(false)
      setNewAppt({ doctor: "", specialty: "", date: "", type: "In-Person", location: "" })
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "Booking failed." })
    }
  }

  if (!mounted) return null

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline">Appointments</h1>
          <p className="text-muted-foreground mt-1">Manage your clinical visits and telehealth consultations.</p>
        </div>
        <Dialog open={isBookOpen} onOpenChange={setIsBookOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl h-11 px-6 shadow-lg shadow-primary/20 font-bold">
              <Plus className="mr-2 h-4 w-4" /> Book Appointment
            </Button>
          </DialogTrigger>
          <DialogContent className="rounded-3xl">
            <DialogHeader>
              <DialogTitle className="font-headline text-2xl">Book Appointment</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Doctor Name</Label>
                <Input value={newAppt.doctor} onChange={(e) => setNewAppt({...newAppt, doctor: e.target.value})} placeholder="e.g. Dr. Sarah Wilson" className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Specialty</Label>
                <Input value={newAppt.specialty} onChange={(e) => setNewAppt({...newAppt, specialty: e.target.value})} placeholder="e.g. Cardiology" className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Date & Time</Label>
                <Input value={newAppt.date} onChange={(e) => setNewAppt({...newAppt, date: e.target.value})} placeholder="e.g. Oct 24, 2:30 PM" className="rounded-xl" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Input value={newAppt.type} onChange={(e) => setNewAppt({...newAppt, type: e.target.value})} placeholder="In-Person / Telehealth" className="rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input value={newAppt.location} onChange={(e) => setNewAppt({...newAppt, location: e.target.value})} placeholder="Suite or Link" className="rounded-xl" />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleBookAppointment} className="rounded-xl w-full font-bold">Confirm Booking</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-6">
          <Tabs defaultValue="upcoming" className="w-full">
            <div className="flex items-center justify-between mb-6">
              <TabsList className="bg-muted/50 p-1 rounded-xl">
                <TabsTrigger value="upcoming" className="rounded-lg px-6 font-bold">Upcoming</TabsTrigger>
                <TabsTrigger value="past" className="rounded-lg px-6 font-bold">Past Visits</TabsTrigger>
              </TabsList>
              <div className="relative hidden md:block w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search appointments..." className="pl-10 h-10 rounded-xl" />
              </div>
            </div>

            <TabsContent value="upcoming" className="space-y-4 m-0">
              {loading ? (
                <div className="py-10 text-center text-muted-foreground">Loading...</div>
              ) : appointments?.length === 0 ? (
                <div className="py-20 text-center text-muted-foreground italic">No upcoming appointments.</div>
              ) : (
                appointments?.map((apt) => (
                  <Card key={apt.id} className="border-none shadow-sm rounded-2xl overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="flex items-start gap-5">
                          <Avatar className="h-14 w-14 border-2 border-primary/10">
                            <AvatarImage src={apt.image} />
                            <AvatarFallback><User /></AvatarFallback>
                          </Avatar>
                          <div className="space-y-1">
                            <h4 className="text-xl font-bold">{apt.doctor}</h4>
                            <p className="text-sm font-medium text-primary">{apt.specialty}</p>
                            <div className="flex items-center gap-4 mt-2">
                               <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                                  <CalendarIcon className="w-4 h-4" />
                                  <span>{apt.date}</span>
                               </div>
                               <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                                  {apt.type === "Telehealth" ? <Video className="w-4 h-4" /> : <MapPin className="w-4 h-4" />}
                                  <span>{apt.location}</span>
                               </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-none px-4 py-1.5 rounded-full font-bold">
                            {apt.status}
                          </Badge>
                          <Button variant="outline" className="rounded-xl font-bold">Reschedule</Button>
                          <Button variant="ghost" size="icon" className="rounded-xl">
                            <ChevronRight className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="past" className="text-center py-20">
              <p className="text-muted-foreground italic">No past appointments found in the last 3 months.</p>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm rounded-2xl bg-primary text-primary-foreground overflow-hidden">
            <CardHeader>
              <CardTitle className="text-lg font-headline">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               <div>
                  <p className="text-xs opacity-70 uppercase tracking-widest font-bold mb-1">Total Visits</p>
                  <p className="text-3xl font-black">{appointments?.length || 0}</p>
               </div>
               <div>
                  <p className="text-xs opacity-70 uppercase tracking-widest font-bold mb-1">Canceled</p>
                  <p className="text-3xl font-black">0</p>
               </div>
               <div className="pt-4 border-t border-white/10">
                  <p className="text-sm font-medium">Regular checkups help in early detection of potential issues.</p>
               </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm rounded-2xl bg-white border border-border">
             <CardHeader>
                <CardTitle className="text-lg font-headline">Pre-Visit Checklist</CardTitle>
             </CardHeader>
             <CardContent className="space-y-3">
                {[
                  "Recent lab reports",
                  "Current medications list",
                  "Symptom log (last 7 days)",
                  "Insurance card"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm font-medium">
                    <div className="w-5 h-5 rounded-full border-2 border-primary/20 flex items-center justify-center text-[10px] font-bold text-primary">{i+1}</div>
                    {item}
                  </div>
                ))}
             </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
