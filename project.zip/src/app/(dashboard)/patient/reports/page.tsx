"use client"

import { useState, useMemo, useEffect } from "react"
import { FileText, Upload, Search, Trash2, Eye, Sparkles, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { aiMedicalReportSummarization } from "@/ai/flows/ai-medical-report-summarization-flow"
import { useCollection, useUser, useFirestore } from "@/firebase"
import { collection, deleteDoc, doc, updateDoc, addDoc, serverTimestamp } from "firebase/firestore"
import { Label } from "@/components/ui/label"
import { toast } from "@/hooks/use-toast"

export default function ReportsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const [summarizing, setSummarizing] = useState(false)
  const [selectedReport, setSelectedReport] = useState<any>(null)
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [fileDataUri, setFileDataUri] = useState<string | null>(null)
  const [newReport, setNewReport] = useState({ name: "", category: "General", date: "" })

  const userId = user?.uid || "guest-user"

  useEffect(() => {
    // Set initial date on the client to avoid hydration mismatch
    setNewReport(prev => ({ ...prev, date: new Date().toISOString().split('T')[0] }))
  }, [])

  const reportsQuery = useMemo(() => {
    if (!db) return null
    return collection(db, "users", userId, "reports")
  }, [db, userId])

  const { data: reports, loading } = useCollection(reportsQuery)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFileDataUri(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSummarize = async (reportId: string, dataUri: string) => {
    if (!db) return
    setSummarizing(true)
    try {
      const res = await aiMedicalReportSummarization({
        reportDataUri: dataUri || "data:text/plain;base64,TW9jayByZXBvcnQ..." 
      })
      
      const reportRef = doc(db, "users", userId, "reports", reportId)
      await updateDoc(reportRef, {
        summary: res.summary,
        status: "Analyzed"
      })
      toast({ title: "Analyzed", description: "AI summary generated successfully." })
    } catch (error) {
      console.error(error)
      toast({ variant: "destructive", title: "Error", description: "Analysis failed." })
    } finally {
      setSummarizing(false)
    }
  }

  const handleDelete = async (reportId: string) => {
    if (!db) return
    const reportRef = doc(db, "users", userId, "reports", reportId)
    try {
      await deleteDoc(reportRef)
      toast({ title: "Deleted", description: "Report removed from database." })
    } catch (e) {
      toast({ variant: "destructive", title: "Error", description: "Failed to delete." })
    }
  }

  const handleAddReport = async () => {
    if (!db || !newReport.name) return
    try {
      await addDoc(collection(db, "users", userId, "reports"), {
        ...newReport,
        status: "Pending",
        summary: "",
        dataUri: fileDataUri || "",
        createdAt: serverTimestamp()
      })
      toast({ title: "Success", description: "Report stored in your health vault." })
      setIsUploadOpen(false)
      setNewReport({ name: "", category: "General", date: new Date().toISOString().split('T')[0] })
      setFileDataUri(null)
    } catch (e) {
      toast({ variant: "destructive", title: "Error", description: "Failed to upload." })
    }
  }

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline">Medical Reports</h1>
          <p className="text-muted-foreground mt-1">Your secure database of clinical findings and AI-powered insights.</p>
        </div>
        <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl h-11 px-6 shadow-lg shadow-primary/20 font-bold">
              <Upload className="mr-2 h-4 w-4" /> Upload New Report
            </Button>
          </DialogTrigger>
          <DialogContent className="rounded-3xl">
            <DialogHeader>
              <DialogTitle className="font-headline text-2xl">Upload to Database</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Report Name</Label>
                <Input value={newReport.name} onChange={(e) => setNewReport({...newReport, name: e.target.value})} placeholder="e.g. Annual Blood Work" className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Input value={newReport.category} onChange={(e) => setNewReport({...newReport, category: e.target.value})} placeholder="e.g. Laboratory" className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Select File (PDF/Image)</Label>
                <Input type="file" onChange={handleFileChange} className="rounded-xl pt-2" />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleAddReport} className="rounded-xl w-full font-bold">Save to Records</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-none shadow-sm rounded-2xl bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-headline">Total Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-black">{reports?.length || 0}</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm rounded-2xl bg-white border">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-headline text-primary">Analyzed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-black">{reports?.filter(r => r.status === "Analyzed").length || 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead className="font-bold py-4 px-6 text-foreground">Report Name</TableHead>
                <TableHead className="font-bold text-foreground">Category</TableHead>
                <TableHead className="font-bold text-foreground">Date</TableHead>
                <TableHead className="font-bold text-foreground">Status</TableHead>
                <TableHead className="text-right font-bold pr-6 text-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">Accessing database...</TableCell>
                </TableRow>
              ) : reports?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-12 text-muted-foreground italic">No reports found. Start building your database.</TableCell>
                </TableRow>
              ) : (
                reports?.map((report) => (
                  <TableRow key={report.id} className="hover:bg-muted/10">
                    <TableCell className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
                          <FileText className="w-5 h-5 text-red-500" />
                        </div>
                        <span className="font-medium text-foreground">{report.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="rounded-full px-3 py-1 bg-white">{report.category}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{report.date}</TableCell>
                    <TableCell>
                      <Badge className={report.status === "Analyzed" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                        {report.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right pr-6">
                      <div className="flex items-center justify-end gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="rounded-lg hover:bg-primary/10 hover:text-primary"
                              onClick={() => setSelectedReport(report)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-3xl rounded-3xl">
                            <DialogHeader>
                              <DialogTitle className="text-2xl font-headline flex items-center gap-2">
                                <FileText className="text-primary" />
                                {selectedReport?.name}
                              </DialogTitle>
                            </DialogHeader>
                            
                            <div className="space-y-6 py-4">
                              <div className="p-6 bg-muted/30 rounded-2xl border border-dashed border-muted-foreground/20 text-center min-h-[150px] flex items-center justify-center flex-col gap-4">
                                  <FileText className="w-12 h-12 text-muted-foreground opacity-30" />
                                  <p className="text-muted-foreground text-sm">Clinical report data is stored securely.</p>
                              </div>

                              <div className="space-y-4">
                                  <div className="flex items-center justify-between">
                                    <h4 className="font-bold flex items-center gap-2">
                                      <Sparkles className="w-4 h-4 text-primary" />
                                      AI Simplified Summary
                                    </h4>
                                    {!report.summary && !summarizing && (
                                      <Button onClick={() => handleSummarize(report.id, report.dataUri)} size="sm" className="rounded-xl">
                                        Analyze Report
                                      </Button>
                                    )}
                                  </div>
                                  
                                  {summarizing ? (
                                    <div className="p-6 rounded-2xl bg-primary/5 border border-primary/10 flex flex-col items-center justify-center gap-3">
                                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                                      <p className="text-sm font-medium">MediTrack AI is analyzing findings...</p>
                                    </div>
                                  ) : report.summary ? (
                                    <div className="p-6 rounded-2xl bg-primary/5 border border-primary/10 animate-in fade-in">
                                      <p className="text-sm leading-relaxed text-slate-800">{report.summary}</p>
                                    </div>
                                  ) : (
                                    <p className="text-sm text-muted-foreground italic">Use the AI analysis to break down complex medical terms.</p>
                                  )}
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button variant="ghost" size="icon" className="rounded-lg hover:bg-destructive/10 hover:text-destructive" onClick={() => handleDelete(report.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
