"use client"

import { useState, useMemo, useEffect } from "react"
import { Activity, Heart, Droplets, Gauge, Footprints, Flame, Pill, Calendar, MessageSquare, Plus, TrendingUp, ShieldCheck } from "lucide-react"
import { VitalCard } from "@/components/dashboard/vital-card"
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from "recharts"
import { Button } from "@/components/ui/button"
import { useCollection, useUser, useFirestore } from "@/firebase"
import { collection, query, orderBy, limit, addDoc, serverTimestamp } from "firebase/firestore"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { toast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

const activityData = [
  { time: "6am", steps: 400 },
  { time: "9am", steps: 2200 },
  { time: "12pm", steps: 1800 },
  { time: "3pm", steps: 3500 },
  { time: "6pm", steps: 4200 },
  { time: "9pm", steps: 1200 },
]

export default function PatientDashboard() {
  const { user } = useUser()
  const db = useFirestore()
  const [isLogOpen, setIsLogOpen] = useState(false)
  const [newVital, setNewVital] = useState({ type: "heart-rate", value: "", unit: "BPM" })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const userId = user?.uid || "guest-user"

  const vitalsQuery = useMemo(() => {
    if (!db) return null
    return query(collection(db, "users", userId, "vitals"), orderBy("timestamp", "desc"), limit(20))
  }, [db, userId])

  const { data: vitalsRecords } = useCollection(vitalsQuery)

  const getLatestVital = (type: string, fallback: string) => {
    const record = vitalsRecords?.find(v => v.type === type)
    return record?.value || fallback
  }

  const chartData = useMemo(() => {
    if (!vitalsRecords || vitalsRecords.length === 0) {
      return [
        { day: "Mon", value: 72 }, { day: "Tue", value: 75 }, { day: "Wed", value: 68 },
        { day: "Thu", value: 82 }, { day: "Fri", value: 78 }, { day: "Sat", value: 85 }, { day: "Sun", value: 80 },
      ]
    }
    const records = [...vitalsRecords].reverse().slice(-7)
    return records.map((r, i) => ({
      day: r.timestamp && typeof r.timestamp === 'object' && 'seconds' in r.timestamp 
        ? new Date(r.timestamp.seconds * 1000).toLocaleDateString([], { weekday: 'short' }) 
        : `Day ${i+1}`,
      value: parseFloat(r.value) || 0
    }))
  }, [vitalsRecords])

  const handleLogVital = async () => {
    if (!db || !newVital.value) {
      toast({ variant: "destructive", title: "Error", description: "Please enter a value." })
      return
    }
    try {
      await addDoc(collection(db, "users", userId, "vitals"), {
        ...newVital,
        timestamp: serverTimestamp()
      })
      toast({ title: "Success", description: `${newVital.type} logged in database.` })
      setIsLogOpen(false)
      setNewVital({ ...newVital, value: "" })
    } catch (e) {
      toast({ variant: "destructive", title: "Database Error", description: "Could not save health record." })
    }
  }

  const updateVitalType = (type: string) => {
    let unit = "BPM"
    if (type === "blood-pressure") unit = "mmHg"
    if (type === "glucose") unit = "mg/dL"
    if (type === "steps") unit = "steps"
    if (type === "calories") unit = "kcal"
    if (type === "oxygen") unit = "%"
    setNewVital({ ...newVital, type, unit })
  }

  if (!mounted) return null

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
             <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-100 font-black tracking-widest text-[10px] uppercase">
                <ShieldCheck className="w-3 h-3 mr-1" /> Clinical Database Active
             </Badge>
          </div>
          <h1 className="text-4xl font-black font-headline text-foreground tracking-tight">Patient Overview</h1>
          <p className="text-muted-foreground mt-1 font-medium">
            Real-time synchronization with your clinical records.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/patient/reports">
            <Button variant="outline" className="rounded-2xl border-2 font-bold h-12 hidden md:flex">
               View Reports
            </Button>
          </Link>
          <Dialog open={isLogOpen} onOpenChange={setIsLogOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-2xl bg-primary text-primary-foreground shadow-2xl shadow-primary/30 hover:bg-primary/90 h-12 px-8 font-black text-lg">
                <Plus className="mr-2 h-5 w-5" /> Log Metric
              </Button>
            </DialogTrigger>
            <DialogContent className="rounded-[2.5rem] border-none shadow-2xl">
              <DialogHeader>
                <DialogTitle className="font-headline text-3xl font-black">Record Health Metric</DialogTitle>
                <DialogDescription className="font-medium">Data is stored securely in your private medical vault.</DialogDescription>
              </DialogHeader>
              <div className="space-y-6 py-6">
                <div className="space-y-2">
                  <Label className="font-bold text-sm uppercase tracking-widest text-muted-foreground">Select Metric</Label>
                  <Select value={newVital.type} onValueChange={updateVitalType}>
                    <SelectTrigger className="rounded-2xl h-14 bg-muted/30 border-none text-lg font-medium">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-2xl">
                      <SelectItem value="heart-rate">Heart Rate</SelectItem>
                      <SelectItem value="blood-pressure">Blood Pressure</SelectItem>
                      <SelectItem value="glucose">Glucose Level</SelectItem>
                      <SelectItem value="steps">Daily Steps</SelectItem>
                      <SelectItem value="calories">Calories</SelectItem>
                      <SelectItem value="oxygen">Oxygen Level</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold text-sm uppercase tracking-widest text-muted-foreground">Current Value ({newVital.unit})</Label>
                  <Input 
                    placeholder="e.g. 72" 
                    value={newVital.value} 
                    onChange={(e) => setNewVital({...newVital, value: e.target.value})}
                    className="rounded-2xl h-14 bg-muted/30 border-none text-2xl font-black placeholder:text-muted-foreground/30"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleLogVital} className="rounded-2xl w-full h-14 font-black text-xl shadow-xl shadow-primary/20">
                   Commit to Records
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <VitalCard 
          title="Heart Rate"
          value={getLatestVital("heart-rate", "72")}
          unit="BPM"
          icon={Heart}
          trend="down"
          trendValue="1.4%"
          status="normal"
          color="bg-rose-500"
        />
        <VitalCard 
          title="Blood Pressure"
          value={getLatestVital("blood-pressure", "120/80")}
          unit="mmHg"
          icon={Activity}
          trend="up"
          trendValue="0.2%"
          status="normal"
          color="bg-primary"
        />
        <VitalCard 
          title="Glucose Level"
          value={getLatestVital("glucose", "98")}
          unit="mg/dL"
          icon={Droplets}
          trend="down"
          trendValue="2.8%"
          status="normal"
          color="bg-cyan-500"
        />
        <VitalCard 
          title="Daily Steps"
          value={getLatestVital("steps", "8,432")}
          unit="steps"
          icon={Footprints}
          trend="up"
          trendValue="14%"
          status="normal"
          color="bg-emerald-500"
        />
        <VitalCard 
          title="Calories"
          value={getLatestVital("calories", "1,840")}
          unit="kcal"
          icon={Flame}
          trend="up"
          trendValue="3.1%"
          status="normal"
          color="bg-orange-500"
        />
         <VitalCard 
          title="Oxygen Level"
          value={getLatestVital("oxygen", "99")}
          unit="%"
          icon={Gauge}
          trend="up"
          trendValue="1.0%"
          status="normal"
          color="bg-indigo-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="border-none shadow-2xl rounded-[2.5rem] bg-white overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between p-10 pb-0">
            <div>
              <CardTitle className="font-headline text-3xl font-black">Clinical Trends</CardTitle>
              <CardDescription className="text-lg font-medium">Historical analysis from synchronized clinical logs</CardDescription>
            </div>
            <div className="p-4 bg-primary/5 rounded-2xl">
               <TrendingUp className="text-primary w-6 h-6" />
            </div>
          </CardHeader>
          <CardContent className="h-[350px] w-full mt-8 p-6">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b', fontWeight: 700}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b', fontWeight: 700}} />
                <Tooltip 
                  contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)', fontWeight: 700}} 
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#2563EB" 
                  strokeWidth={5}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-2xl rounded-[2.5rem] bg-white overflow-hidden">
          <CardHeader className="p-10 pb-0">
            <CardTitle className="font-headline text-3xl font-black">Activity Distribution</CardTitle>
            <CardDescription className="text-lg font-medium">Daily steps logged across temporal checkpoints</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px] w-full mt-8 p-6">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b', fontWeight: 700}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b', fontWeight: 700}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)', fontWeight: 700}} 
                />
                <Bar 
                  dataKey="steps" 
                  fill="#21A6CF" 
                  radius={[12, 12, 0, 0]}
                  barSize={45}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
        <Card className="border-none shadow-2xl rounded-[2.5rem] bg-primary text-primary-foreground overflow-hidden relative group">
          <div className="absolute right-0 top-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:scale-125 transition-transform duration-700"></div>
          <CardHeader className="p-10 pb-6">
            <CardTitle className="font-headline text-3xl font-black text-white flex items-center gap-3">
              <Pill className="w-8 h-8" />
              Prescriptions
            </CardTitle>
            <CardDescription className="text-primary-foreground/70 text-lg font-medium">Managed clinical logs</CardDescription>
          </CardHeader>
          <CardContent className="px-10 pb-10">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-xl font-bold">Sync Schedule</p>
                <p className="text-sm opacity-80 font-medium">Auto-reminders active</p>
              </div>
              <Link href="/patient/medications">
                <Button variant="secondary" className="rounded-2xl font-black px-8 h-12 text-lg">Manage</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-white group">
          <CardHeader className="p-10 pb-4">
            <CardTitle className="font-headline text-3xl font-black flex items-center gap-3">
              <Calendar className="w-8 h-8 text-primary" />
              Clinical Visits
            </CardTitle>
          </CardHeader>
          <CardContent className="px-10 pb-10">
            <p className="text-lg font-medium text-muted-foreground mb-8">Clinical data is securely replicated across nodes.</p>
            <Link href="/patient/appointments">
              <Button variant="outline" className="w-full rounded-2xl h-14 group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-all font-black text-lg shadow-xl shadow-slate-100">Access Records</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-cyan-600 border border-cyan-500 relative group">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-cyan-700 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <CardHeader className="p-10 pb-4 relative z-10">
            <CardTitle className="font-headline text-3xl font-black text-white flex items-center gap-3">
              <MessageSquare className="w-8 h-8" />
              AI Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="px-10 pb-10 relative z-10">
            <p className="text-lg font-medium text-cyan-50 leading-relaxed mb-8">Integrated clinical reasoning with 24/7 record access.</p>
            <Link href="/patient/chat" className="block w-full">
              <Button className="w-full rounded-2xl h-14 bg-white hover:bg-white/90 text-cyan-700 font-black text-lg shadow-xl shadow-cyan-900/20">Analyze Now</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
