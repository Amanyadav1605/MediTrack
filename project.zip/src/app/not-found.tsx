
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { FileQuestion, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#F8F9FB] text-center">
      <div className="w-20 h-20 bg-primary/5 rounded-full flex items-center justify-center mb-8">
        <FileQuestion className="w-10 h-10 text-primary" />
      </div>
      <h1 className="text-6xl font-black font-headline text-primary mb-4">404</h1>
      <h2 className="text-3xl font-bold font-headline mb-2">Page Not Found</h2>
      <p className="text-muted-foreground max-w-md mb-10 text-lg">
        The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
      </p>
      <Link href="/">
        <Button className="h-12 rounded-xl font-bold px-8 shadow-xl shadow-primary/20">
          <ArrowLeft className="mr-2 h-5 w-5" /> Back to Safety
        </Button>
      </Link>
    </div>
  )
}
