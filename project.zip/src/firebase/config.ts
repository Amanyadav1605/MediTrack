'use client';

/**
 * Firebase configuration object.
 * Updated with the user-provided API key.
 */
export const firebaseConfig = {
  apiKey: "AQ.Ab8RN6LmfUXFmyFp_y4MML-ptGAJvSH0T61-r5auluxRYCuc1w",
  authDomain: "meditrack-proto.firebaseapp.com",
  projectId: "meditrack-proto",
  storageBucket: "meditrack-proto.appspot.com",
  messagingSenderId: "178118780341",
  appId: "1:178118780341:web:5838573928573928573928",
};

export const isConfigPlaceholder = false;
