'use server';
/**
 * @fileOverview Provides a Genkit flow for summarizing medical reports.
 *
 * - aiMedicalReportSummarization - A function that summarizes medical reports for patients.
 * - AiMedicalReportSummarizationInput - The input type for the aiMedicalReportSummarization function.
 * - AiMedicalReportSummarizationOutput - The return type for the aiMedicalReportSummarization function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiMedicalReportSummarizationInputSchema = z.object({
  reportDataUri: z
    .string()
    .describe(
      "A medical report (PDF or image), as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    )
    .refine(data => data.startsWith('data:'), {
      message: 'reportDataUri must be a data URI',
    }),
});
export type AiMedicalReportSummarizationInput = z.infer<
  typeof AiMedicalReportSummarizationInputSchema
>;

const AiMedicalReportSummarizationOutputSchema = z.object({
  summary: z
    .string()
    .describe(
      'A clear, simplified summary of the key findings, possible conditions, and suggested actions from the medical report, free of complex medical jargon.'
    ),
});
export type AiMedicalReportSummarizationOutput = z.infer<
  typeof AiMedicalReportSummarizationOutputSchema
>;

export async function aiMedicalReportSummarization(
  input: AiMedicalReportSummarizationInput
): Promise<AiMedicalReportSummarizationOutput> {
  return aiMedicalReportSummarizationFlow(input);
}

const aiMedicalReportSummarizationPrompt = ai.definePrompt({
  name: 'aiMedicalReportSummarizationPrompt',
  input: {schema: AiMedicalReportSummarizationInputSchema},
  output: {schema: AiMedicalReportSummarizationOutputSchema},
  prompt: `You are an AI assistant specialized in medical report summarization for patients. Your goal is to simplify complex medical jargon into easy-to-understand language, focusing on key findings, possible conditions, and suggested next steps, directly addressing the patient.

Summarize the provided medical report. Do not include any disclaimers about not being a medical professional.

Medical Report: {{media url=reportDataUri}}`,
});

const aiMedicalReportSummarizationFlow = ai.defineFlow(
  {
    name: 'aiMedicalReportSummarizationFlow',
    inputSchema: AiMedicalReportSummarizationInputSchema,
    outputSchema: AiMedicalReportSummarizationOutputSchema,
  },
  async input => {
    const {output} = await aiMedicalReportSummarizationPrompt(input);
    if (!output) {
      throw new Error('Failed to generate medical report summary.');
    }
    return output;
  }
);
