'use server';
/**
 * @fileOverview This file implements an AI symptom analysis flow.
 *
 * - aiSymptomAnalysis - A function that analyzes patient symptoms and provides potential conditions, severity, and actions.
 * - AiSymptomAnalysisInput - The input type for the aiSymptomAnalysis function.
 * - AiSymptomAnalysisOutput - The return type for the aiSymptomAnalysis function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiSymptomAnalysisInputSchema = z.object({
  symptoms: z.string().describe('A detailed description of the patient\'s symptoms. Include duration, intensity, and any relevant details.'),
  age: z.number().int().min(0).max(120).describe('The patient\'s age in years.'),
  gender: z.enum(['Male', 'Female', 'Other', 'Prefer not to say']).describe('The patient\'s gender.'),
  existingDiseases: z.array(z.string()).optional().describe('A list of any pre-existing medical conditions or diseases the patient has, if applicable.'),
});
export type AiSymptomAnalysisInput = z.infer<typeof AiSymptomAnalysisInputSchema>;

const AiSymptomAnalysisOutputSchema = z.object({
  possibleConditions: z.array(z.object({
    name: z.string().describe('The name of the possible health condition.'),
    description: z.string().describe('A brief description of the condition.'),
    confidencePercentage: z.number().min(0).max(100).describe('The AI\'s confidence level (0-100%) in this condition being a possible cause.'),
  })).describe('A list of possible health conditions identified by the AI, along with descriptions and confidence levels.'),
  severityScore: z.number().int().min(1).max(10).describe('An integer score from 1 (mild) to 10 (severe) indicating the overall urgency and potential severity of the symptoms.'),
  suggestedActions: z.array(z.string()).describe('A list of immediate actions the patient should consider, such as monitoring symptoms, resting, or seeking professional medical advice.'),
  recommendationToConsultDoctor: z.boolean().describe('True if the AI strongly recommends consulting a medical doctor for further evaluation, false otherwise.'),
});
export type AiSymptomAnalysisOutput = z.infer<typeof AiSymptomAnalysisOutputSchema>;

export async function aiSymptomAnalysis(input: AiSymptomAnalysisInput): Promise<AiSymptomAnalysisOutput> {
  return aiSymptomAnalysisFlow(input);
}

const symptomAnalysisPrompt = ai.definePrompt({
  name: 'symptomAnalysisPrompt',
  input: { schema: AiSymptomAnalysisInputSchema },
  output: { schema: AiSymptomAnalysisOutputSchema },
  prompt: `You are an AI-powered medical assistant designed to help users understand their symptoms.
Your goal is to analyze the provided patient information and symptoms to identify possible health conditions, assess their severity, and suggest appropriate immediate actions.
IMPORTANT: This is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.

Analyze the following patient data:
Age: {{{age}}} years old
Gender: {{{gender}}}
Symptoms: {{{symptoms}}}
{{#if existingDiseases}}
Existing Medical Conditions: {{#each existingDiseases}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
{{/if}}

Based on this information, provide:
1.  A list of possible health conditions, including a brief description and your confidence level (0-100%).
2.  An overall severity score for the situation (1-10, where 1 is mild and 10 is very severe/urgent).
3.  A list of suggested immediate actions the patient should consider.
4.  A clear recommendation on whether the patient should consult a doctor.

Ensure your response is structured exactly as per the output JSON schema provided.`,
});

const aiSymptomAnalysisFlow = ai.defineFlow(
  {
    name: 'aiSymptomAnalysisFlow',
    inputSchema: AiSymptomAnalysisInputSchema,
    outputSchema: AiSymptomAnalysisOutputSchema,
  },
  async (input) => {
    const { output } = await symptomAnalysisPrompt(input);
    if (!output) {
      throw new Error('AI symptom analysis failed to produce output.');
    }
    return output;
  }
);
