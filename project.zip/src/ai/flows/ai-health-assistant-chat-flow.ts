
'use server';
/**
 * @fileOverview An integrated AI health assistant flow.
 *
 * - aiHealthAssistantChat - Processes user messages with tool access to health data.
 * - AiHealthAssistantChatInput - Input schema including userId for database access.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import {initializeFirebase} from '@/firebase';
import {collection, query, orderBy, limit, getDocs} from 'firebase/firestore';
import {googleAI} from '@genkit-ai/google-genai';

const AiHealthAssistantChatInputSchema = z.object({
  userId: z.string().describe('The ID of the user for retrieving their health data.'),
  message: z.string().describe("The user's current chat message."),
  chatHistory: z
    .array(
      z.object({
        role: z.enum(['user', 'model']),
        content: z.string(),
      })
    )
    .optional()
    .describe('Previous chat messages for context.'),
});
export type AiHealthAssistantChatInput = z.infer<typeof AiHealthAssistantChatInputSchema>;

const AiHealthAssistantChatOutputSchema = z.object({
  response: z.string().describe("The AI's natural language response."),
});
export type AiHealthAssistantChatOutput = z.infer<typeof AiHealthAssistantChatOutputSchema>;

/** Helper to format Firestore dates for the LLM */
const formatFirestoreData = (data: any) => {
  const formatted = { ...data };
  for (const key in formatted) {
    if (formatted[key] && typeof formatted[key] === 'object' && 'toDate' in formatted[key]) {
      formatted[key] = formatted[key].toDate().toISOString();
    } else if (formatted[key] && typeof formatted[key] === 'object' && 'seconds' in formatted[key]) {
      // Handle raw timestamp objects if toDate isn't available
      formatted[key] = new Date(formatted[key].seconds * 1000).toISOString();
    }
  }
  return formatted;
};

// Tool to get user's latest vitals
const getLatestVitals = ai.defineTool(
  {
    name: 'getLatestVitals',
    description: "Retrieves the user's most recent vital sign records. Use this to check heart rate, blood pressure, etc.",
    inputSchema: z.object({ userId: z.string().describe('The ID of the user.') }),
    outputSchema: z.array(z.any()),
  },
  async (input) => {
    const {firestore} = initializeFirebase();
    const vitalsRef = collection(firestore, 'users', input.userId, 'vitals');
    const q = query(vitalsRef, orderBy('timestamp', 'desc'), limit(15));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => formatFirestoreData(doc.data()));
  }
);

// Tool to get user's medications
const getMedications = ai.defineTool(
  {
    name: 'getMedications',
    description: "Retrieves the user's active medication prescriptions and their statuses.",
    inputSchema: z.object({ userId: z.string().describe('The ID of the user.') }),
    outputSchema: z.array(z.any()),
  },
  async (input) => {
    const {firestore} = initializeFirebase();
    const medsRef = collection(firestore, 'users', input.userId, 'medications');
    const snapshot = await getDocs(medsRef);
    return snapshot.docs.map(doc => formatFirestoreData(doc.data()));
  }
);

// Tool to get user's appointments
const getAppointments = ai.defineTool(
  {
    name: 'getAppointments',
    description: "Retrieves the user's upcoming medical appointments.",
    inputSchema: z.object({ userId: z.string().describe('The ID of the user.') }),
    outputSchema: z.array(z.any()),
  },
  async (input) => {
    const {firestore} = initializeFirebase();
    const apptsRef = collection(firestore, 'users', input.userId, 'appointments');
    const snapshot = await getDocs(apptsRef);
    return snapshot.docs.map(doc => formatFirestoreData(doc.data()));
  }
);

export async function aiHealthAssistantChat(input: AiHealthAssistantChatInput): Promise<AiHealthAssistantChatOutput> {
  return aiHealthAssistantChatFlow(input);
}

const aiHealthAssistantChatFlow = ai.defineFlow(
  {
    name: 'aiHealthAssistantChatFlow',
    inputSchema: AiHealthAssistantChatInputSchema,
    outputSchema: AiHealthAssistantChatOutputSchema,
  },
  async (input) => {
    const systemInstruction = `You are MediTrack AI, a highly capable clinical health assistant.
Your goal is to provide data-driven, intelligent, and proactive healthcare insights.

CORE DIRECTIVES:
1. Always prioritize checking available user data tools when asked about vitals, meds, or schedule.
2. If data is missing, explain how the user can log it.
3. Use a professional, empathetic tone.
4. If vitals are abnormal (e.g., HR > 100 at rest, BP > 140/90), provide a cautionary summary and suggest monitoring.
5. Provide a summary of data trends if multiple records are retrieved.

USER CONTEXT:
- Target User ID: ${input.userId}
- Current Local Time: ${new Date().toLocaleString()}

CONSTRAINTS:
- NEVER give definitive medical diagnoses.
- Use phrasing like "Your records suggest..." or "Based on your clinical logs...".
- ALWAYS include: "Please consult a healthcare professional for clinical decisions."

You are authorized to access: Vitals, Medications, and Appointments.`;

    const messages: any[] = [
      {
        role: 'system',
        content: [{ text: systemInstruction }]
      },
    ];

    if (input.chatHistory) {
      messages.push(...input.chatHistory.map(h => ({
        role: h.role,
        content: [{ text: h.content }]
      })));
    }

    messages.push({
      role: 'user',
      content: [{ text: input.message }]
    });

    const response = await ai.generate({
      model: googleAI.model('gemini-flash-latest'),
      prompt: messages,
      tools: [getLatestVitals, getMedications, getAppointments],
      config: {
        temperature: 0.4, // Lower temperature for more clinical/factual responses
      }
    });

    if (!response.text) {
      throw new Error('AI Engine failed to generate a response.');
    }

    return { response: response.text };
  }
);
