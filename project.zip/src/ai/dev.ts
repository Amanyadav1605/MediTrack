import { config } from 'dotenv';
config();

import '@/ai/flows/ai-medical-report-summarization-flow.ts';
import '@/ai/flows/ai-symptom-analysis-flow.ts';
import '@/ai/flows/ai-health-assistant-chat-flow.ts';