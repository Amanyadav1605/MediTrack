"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { 
  LayoutDashboard, 
  Stethoscope, 
  MessageSquare, 
  FileText, 
  Pill, 
  Calendar, 
  Activity,
  AlertCircle,
  Home
} from "lucide-react"

import { cn } from "@/lib/utils"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"

const navItems = [
  {
    title: "Health Overview",
    url: "/patient",
    icon: LayoutDashboard,
  },
  {
    title: "Symptom Analysis",
    url: "/patient/symptoms",
    icon: Stethoscope,
  },
  {
    title: "AI Health Chat",
    url: "/patient/chat",
    icon: MessageSquare,
  },
  {
    title: "Medical Reports",
    url: "/patient/reports",
    icon: FileText,
  },
  {
    title: "Medications",
    url: "/patient/medications",
    icon: Pill,
  },
  {
    title: "Appointments",
    url: "/patient/appointments",
    icon: Calendar,
  },
]

export function AppSidebar() {
  const pathname = usePathname()

  return (
    <Sidebar collapsible="icon" className="border-r bg-white">
      <SidebarHeader className="h-16 flex items-center px-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Activity className="text-white w-5 h-5" />
          </div>
          <span className="font-headline font-bold text-xl tracking-tight group-data-[collapsible=icon]:hidden">
            MediTrack
          </span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="px-6 py-4 font-semibold text-xs uppercase tracking-wider text-muted-foreground group-data-[collapsible=icon]:hidden">
            Main Menu
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="px-3">
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={pathname === item.url}
                    tooltip={item.title}
                    className={cn(
                      "h-11 rounded-xl transition-all",
                      pathname === item.url 
                        ? "bg-primary/10 text-primary font-medium" 
                        : "hover:bg-accent hover:text-accent-foreground"
                    )}
                  >
                    <Link href={item.url}>
                      <item.icon className="w-5 h-5" />
                      <span className="ml-3 group-data-[collapsible=icon]:hidden">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-auto">
          <SidebarGroupLabel className="px-6 py-4 font-semibold text-xs uppercase tracking-wider text-muted-foreground group-data-[collapsible=icon]:hidden">
            Emergency
          </SidebarGroupLabel>
          <SidebarGroupContent className="px-3">
             <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton className="h-11 rounded-xl text-destructive hover:bg-destructive/10 hover:text-destructive font-bold">
                    <AlertCircle className="w-5 h-5" />
                    <span className="ml-3 group-data-[collapsible=icon]:hidden">SOS Emergency</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
             </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild className="h-11 rounded-xl font-bold text-muted-foreground hover:text-primary">
              <Link href="/">
                <Home className="w-5 h-5" />
                <span className="ml-3 group-data-[collapsible=icon]:hidden">Back to Landing</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
