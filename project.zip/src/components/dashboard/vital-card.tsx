
"use client"

import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface VitalCardProps {
  title: string
  value: string
  unit: string
  icon: LucideIcon
  trend: "up" | "down"
  trendValue: string
  status: "normal" | "warning" | "alert"
  color: string
}

export function VitalCard({ title, value, unit, icon: Icon, trend, trendValue, status, color }: VitalCardProps) {
  return (
    <Card className="overflow-hidden border-none shadow-xl hover:shadow-2xl transition-all duration-300 group rounded-[2.5rem] bg-white">
      <CardContent className="p-0">
        <div className="p-8 flex items-start justify-between">
          <div className="space-y-3">
            <p className="text-sm font-black text-muted-foreground uppercase tracking-widest">{title}</p>
            <div className="flex items-baseline gap-2">
              <h3 className="text-4xl font-black font-headline tracking-tight">{value}</h3>
              <span className="text-base font-bold text-muted-foreground">{unit}</span>
            </div>
          </div>
          <div className={cn("p-5 rounded-[1.5rem] transition-all duration-500 group-hover:rotate-12 group-hover:scale-110 shadow-lg", color)}>
            <Icon className="w-8 h-8 text-white" />
          </div>
        </div>
        <div className="px-8 py-5 bg-slate-50 flex items-center justify-between border-t border-slate-100">
          <div className="flex items-center gap-2">
            <div className={cn(
              "p-1 rounded-full",
              trend === "up" ? "bg-emerald-100" : "bg-emerald-100"
            )}>
               {trend === "up" ? (
                <TrendingUp className="w-4 h-4 text-emerald-600" />
              ) : (
                <TrendingDown className="w-4 h-4 text-emerald-600" />
              )}
            </div>
            <span className="text-sm font-black text-emerald-600 tracking-tight">{trendValue}</span>
            <span className="text-xs text-muted-foreground font-bold ml-1">history</span>
          </div>
          <div className={cn(
            "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.1em]",
            status === "normal" ? "bg-emerald-100 text-emerald-700" : 
            status === "warning" ? "bg-amber-100 text-amber-700" : "bg-destructive/10 text-destructive"
          )}>
            {status}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
